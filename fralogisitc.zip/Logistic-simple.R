#_________________________________________________
#
#  Clean up
#
#_________________________________________________
rm(list=ls())
gc()

#_________________________________________________
#
# Load packages
#
#_________________________________________________

require(caret)
require(plyr)
require(Hmisc)
require(pROC)
require(DMwR)
require(missForest)
require(mi)
require(mice)
require(car)
require(xgboost)
require(Amelia)

#_________________________________________________
#
# Read files
#
#_________________________________________________
setwd('c:/r/data/csv/')
train <- read.csv('fra_train.csv', header=TRUE)
test <- read.csv('fra_test.csv', header=TRUE)

test_dat <- read.csv('fra_test.csv', header=TRUE)

dim(train)
dim(test)


#_________________________________________________
#
# Check missing values
#
#_________________________________________________

missmap(train, col=c('red', 'white'), legend=FALSE)
missmap(test, col=c('red', 'white'), legend=FALSE)


#_________________________________________________
#
# Data Pre-Processing
#
#_________________________________________________

train$SeriousDlqin2yrs <- factor(train$SeriousDlqin2yrs)
test$SeriousDlqin2yrs <- factor(test$SeriousDlqin2yrs)

train$NumberOfDependents <- factor(train$NumberOfDependents)
test$NumberOfDependents <- factor(test$NumberOfDependents)


#_________________________________________________
#
# Let's do some exploratory
#
#_________________________________________________
source('helper.R')
hgraph(train)
hgraph(test)

#_________________________________________________
#
# Let's do imputation based on the above insights
#
#_________________________________________________

#_________________________________________________
#
# Mode Imputation
#
#_________________________________________________


getmode <- function(v) {
 uniqv <- unique(v)
 uniqv[which.max(tabulate(match(v, uniqv)))]
}
 

train$NumberOfDependents[is.na(train$NumberOfDependents)] <- getmode(train$NumberOfDependents)
test$NumberOfDependents[is.na(test$NumberOfDependents)] <- getmode(test$NumberOfDependents)


#_________________________________________________
#
# Now check missing values
#
#_________________________________________________

sapply(train, function(x) sum(is.na(x)))
sapply(test, function(x) sum(is.na(x)))


#_________________________________________________
#
# Derived variables
#
#_________________________________________________




#_________________________________________________
#
# Log Transformation
#
#_________________________________________________

#_________________________________________________
#
# Bin - Transformation
#
#_________________________________________________



#_________________________________________________
#
# Create Dummy Variables
#
#_________________________________________________





#_________________________________________________
#
# Split Data
#
#_________________________________________________

# Remove Loan_ID attribute
df <- train
df <- df[,-1]
test <- test[,-1]

# Split 80/20
trainIndex <- createDataPartition(df$SeriousDlqin2yrs, p=0.8,list=FALSE,times=1)
df_train <- df[trainIndex,];df_valid <- df[-trainIndex,]

# Training scheme - 10-fold CV
ctrl <- trainControl(method='repeatedcv', number=10,repeats=3)


#_________________________________________________
#
# Preparation for xGB Algorithm
#
#_________________________________________________


y <- df_train$SeriousDlqin2yrs
y <-  as.numeric(levels(y))[y]
df_train$SeriousDlqin2yrs <-  as.numeric(levels(df_train$SeriousDlqin2yrs))[df_train$SeriousDlqin2yrs]

df_valid$SeriousDlqin2yrs <-  as.numeric(levels(df_valid$SeriousDlqin2yrs))[df_valid$SeriousDlqin2yrs]


#_________________________________________________
#
# Declare outcome and features
#
#_________________________________________________
outcome_name <- 'SeriousDlqin2yrs'
feature_names <- setdiff(names(df_train), outcome_name)


#_________________________________________________
#
# Train Logisitc regression model
#
#_________________________________________________

logit_fit <- glm(SeriousDlqin2yrs~
                   NumberOfDependents1+
                   NumberOfDependents2+
                   NumberOfDependents7,
              data = df_train,
              family = 'binomial')
               


#_________________________________________________
#
# in-sample accuracy on training sample
#
#_________________________________________________
y_pred <- predict(logit_fit, df_train, type='response')
y_pred <- floor(y_pred+0.5)
df_train$ypred <- y_pred

sum(with(df_train, table(ypred, SeriousDlqin2yrs)))
with(df_train, table(ypred, SeriousDlqin2yrs))

auc(df_train$SeriousDlqin2yrs, df_train$ypred)



#_________________________________________________
#
# validation sample accuracy
#
#_________________________________________________

y_pred <- predict(xgb, data.matrix(df_valid[,feature_names]))
y_pred <- floor(y_pred+0.5)
df_valid$ypred <- y_pred

sum(with(df_valid, table(ypred, SeriousDlqin2yrs)))
with(df_valid, table(ypred, SeriousDlqin2yrs))

auc(df_valid$SeriousDlqin2yrs, df_valid$ypred)


#_________________________________________________
#
# predict on test sample
#
#_________________________________________________

y_pred <- predict(xgb, data.matrix(test[,feature_names]))
y_pred <- floor(y_pred+0.5)
test$ypred <- y_pred

sum(with(test, table(ypred, SeriousDlqin2yrs)))
with(test, table(ypred, SeriousDlqin2yrs))

auc(test$SeriousDlqin2yrs, test$ypred)


#_________________________________________________
#
# unload packages
#
#_________________________________________________
detach('package:caret')
detach('package:plyr')
detach('package:Hmisc')
detach('package:pROC')
detach('package:DMwR')
detach('package:missForest')
detach('package:mi')
detach('package:mice')
detach('package:car')
detach('package:xgboost')
detach('package:Amelia')
detach('package:ggplot2')


#_________________________________________________
#
#  Clean up
#
#_________________________________________________
rm(list=ls())
gc()